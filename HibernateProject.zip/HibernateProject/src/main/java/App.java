import entity.Users;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class App {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure().addAnnotatedClass(Users.class).buildSessionFactory();
        Session session = factory.getCurrentSession();

        try {

            session.beginTransaction();

            //UPDATE USING HQL
//            session.createQuery("update users set password='222222' where lastName='Mihnea'").executeUpdate();

            //DELETE USING HQL
            session.createQuery("delete from users where userId=6").executeUpdate();

            session.getTransaction().commit();

//           List<Users> users = session.createQuery("from users").getResultList();
//
//           for (Users temp: users) {
//               System.out.println(temp);
//           }

//            session.getTransaction().commit();
//            Users user = new Users();
//
//            //Start transaction
//            session.beginTransaction();
//
//            //Perform operation
////            user = session.get(Users.class, 5);
//
//
////            session.save(user);
//
//            //Updating object
//            //user.setUsername("admin@test.com");
//
//            //Delete a record from the DB
////            session.delete(user);
//
//            //Commit the transaction
//            session.getTransaction().commit();
//            System.out.println(user);

        } finally {
            session.close();
            factory.close();
        }
    }
}
